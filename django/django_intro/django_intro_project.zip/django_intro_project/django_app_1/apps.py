from django.apps import AppConfig


class DjangoApp1Config(AppConfig):
    name = 'django_app_1'
